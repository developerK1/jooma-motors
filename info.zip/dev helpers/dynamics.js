const details = {
    name : "Jooma Motors",
    descriptions : ["Jooma's is located in Zeerust North West has a large selection for quality used and brand new cars. We create purchasing environment with professional service in expireinece in buying cars.An environment where a customer can explore his desire on  a wide range of vehicles. ", "Jooma's is located in Zeerust North West has a large selection for quality used and brand new cars. We create purchasing environment with professional service in expireinece in buying cars.An environment where a customer can explore his desire on  a wide range of vehicles. "],
    motto : "Professional purchases service which cater's to your tailored needs ion Zeerust North West and beyond",
    businessEmail : "info@JoomaMott[ors.co.za",
    businessNumbers : "018 642 1230",
    businessWhatsApp :"018 642 1230",
    testo : "From the moment I walked in, the staff greeted me with warmth and professionalism. They listen attentively to my needs and help me find the perfect car that fit my budget.",

}

module.exports = details;